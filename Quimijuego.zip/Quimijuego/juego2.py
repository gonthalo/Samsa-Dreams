import os, inspect, sys, math, random, pygame, pygame.mixer
from time import time
from random import random
from pygame.locals import *

SCREEN_SIZE = SCREEN_WIDTH, SCREEN_HEIGHT = 1200, 700
FPS = 30
PATH = inspect.getfile(inspect.currentframe())[:-9]
#BASICFONT = pygame.font.SysFont("tlwgtypewriter", 50)
ROZ_AIRE = 0.95
ROZ_TIERRA = 0.85
BLOQ = 15
JUGALT = 105
JUGANCH = 45

NEGRO  = (  0,   0,   0, 255)
BLANCO = (255, 255, 255, 255)
NABLA  = ( 10, 250, 120, 255)
VACIO  = (255, 255, 255,   0)



class Imagen:
	def __init__(self, file_name):
		self.area = pygame.image.load(PATH + 'img/' + file_name)
		self.rect = self.area.get_rect()
	def poner(self, i_x, i_y, phi=0):
		SCREEN.blit(pygame.transform.rotate(self.area, phi), self.rect.move(i_x, i_y))

def get_text(texto, fondo, frente, font, size):
	pygame.font.init()
	fuente = pygame.font.SysFont(font, size)
	if fondo == None:
		texto = fuente.render(texto, True, frente)
	else:
		texto = fuente.render(texto, True, frente, fondo)
	img_a = Imagen('bloque1.png')
	img_a.area = texto
	img_a.rect = img_a.area.get_rect()
	return img_a

archivo = open(PATH + 'cosas/bloques', 'r')
bloques = [linea[:-1] for linea in archivo.readlines()]
print bloques
BLOQ_IMGS = [Imagen('bloque' + str(ii) + '.png') for ii in range(len(bloques))]
archivo.close()
FONDO_MENU = Imagen('fondo_menu.png')
FRENTE_MENU = Imagen('frente_menu.png')
TEXTO_MENU = [(get_text('AERONAVE', None, NEGRO, "tlwgtypewriter", 80), -1, 0),
(get_text('Un jueguecito de la mano de AngoSoft', None, NEGRO, "tlwgtypewriter", 15), 70, SCREEN_HEIGHT - 70),
(get_text('Comenzar', None, NEGRO, "arial", 35), 90, 200)]


def main():
	global FPSCLOCK, SCREEN
	pygame.init()
	FPSCLOCK = pygame.time.Clock()
	#pygame.display.set_icon([...])
	SCREEN = pygame.display.set_mode(SCREEN_SIZE)
	pygame.display.set_caption('Aeronave')
	while True:
		runGame()

def runGame():
	KKLEFT = K_LEFT
	KKDOWN = K_DOWN
	KKRIGHT = K_RIGHT
	KKUP = K_UP
	modo_juego = 'menu_principal'
	pausa = False
	jugador = Persona(15, -45, '[nombre]', 'monigote.png')
	pilotando = False
	moveR, moveU, moveD, moveL = False, False, False, False
	gravedad = 0.6
	camara_x, camara_y = 0, 0
	mi_suelo = Suelo(parseimg('suelo_prueba.png'), 'bloque1.png')
	mi_nave = Nave(1500, 1500, [[1, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 1, 1], [1, 1, 1, 1, 1, 1, 1]], ('malo', 'pasivo'))
	barcos = [mi_nave]
	jugador.ancla = mi_nave
	mousex, mousey = 0, 0
	mouseclic = False
	while True:
		FPSCLOCK.tick(FPS)
		if modo_juego == 'normal':
			for event in pygame.event.get():
				if event.type == QUIT:
					terminate()
				if event.type == KEYDOWN:
					if event.key == KKLEFT:
						moveR = False
						moveL = True
					elif event.key == KKDOWN:
						moveD = True
						moveU = False
					elif event.key == KKRIGHT:
						moveR = True
						moveL = False
					elif event.key == KKUP:
						moveD = False
						moveU = True
				elif event.type == KEYUP:
					if event.key == KKLEFT:
						moveL = False
					elif event.key == KKDOWN:
						moveD = False
					elif event.key == KKRIGHT:
						moveR = False
					elif event.key == KKUP:
						moveU = False
					elif event.key == K_n:
						pilotando = not pilotando
					elif event.key == K_p:
						pausa = not pausa
					elif event.key == K_t:
						print 42
						modo_juego = 'menu_principal'
					elif event.key == K_ESCAPE:
						terminate()
					elif event.type == MOUSEMOTION:
						mousex, mousey = event.pos
					elif event.type == MOUSEBUTTONUP:
						mousex, mousey = event.pos
						mouseClicked = True
			if pausa:
				continue
			if pilotando:
				mi_nave.controlar(moveR, moveU, moveD, moveL)
			else:
				jugador.controlar(moveR, moveU, moveD, moveL)
			for barco in barcos:
				barco.mover(gravedad)
			jugador.mover(gravedad, barcos + [mi_suelo])
			SCREEN.fill(NABLA)
			if jugador.ancla:
				camara_x = jugador.x + JUGANCH/2 + jugador.ancla.x - SCREEN_WIDTH/2
				camara_y = jugador.y + JUGALT/2 + jugador.ancla.y - SCREEN_HEIGHT/2
			else:
				camara_x = jugador.x + JUGANCH/2 - SCREEN_WIDTH/2
				camara_y = jugador.y + JUGALT/2 - SCREEN_HEIGHT/2
			mi_suelo.dibujar(camara_x, camara_y)
			for barco in barcos:
				barco.dibujar(camara_x, camara_y)
			jugador.dibujar(camara_x, camara_y)
		if modo_juego == 'menu_principal':
			FONDO_MENU.poner(0, 0)
			spam_imgs(TEXTO_MENU)
			for event in pygame.event.get():
				if event.type == QUIT:
					terminate()
				if event.type == KEYUP:
					if event.key == K_n:
						pilotando = not pilotando
					elif event.key == K_p:
						pausa = not pausa
					elif event.key == K_t:
						print 42
						modo_juego = 'normal'
					elif event.key == K_ESCAPE:
						terminate()
			FRENTE_MENU.poner(0, 0)
		pygame.display.update()



#Ahora las clases, que son:
#Persona # describe a una persona en el juego
#Nave # describe a una aeronave
#Suelo # describe un bloque inmovil de terreno
#Objeto # describe uno de los 'items' del juego
#Boton # define un boton en la pantalla



class Persona:
	def __init__(self, xxx, yyy, nombre, imagen):
		self.x, self.y = xxx, yyy
		self.nombre = nombre
		self.vx, self.vy = 0, 0
		self.agil = 2.
		self.vsalto = 13
		self.ancla = False
		self.imagen = Imagen(imagen)
		self.altura = 7
		self.moveR, self.moveL, self.moveU, self.moveD = False, False, False, False
	def hay_piso(self):
		mix = ynt(self.x/BLOQ)
		miy = ynt((JUGALT + self.y + 0.5)/BLOQ)
		if miy < 0 or miy >= len(self.ancla.matriz):
			return False
		for tt in range(int(JUGANCH/BLOQ) + 1):
			if mix + tt >= 0 and mix + tt < len(self.ancla.matriz[0]):
				if self.ancla.matriz[miy][mix + tt]:
					return True
		return False
	def ground(self, cosa):
		mix = ynt((self.x - cosa.x + 0.3)/BLOQ)
		miy = ynt((JUGALT + self.y - cosa.y + 0.3)/BLOQ)
		if miy < 0 or miy >= len(cosa.matriz):
			return False
		for tt in range(ynt(JUGANCH/BLOQ) + 1):
			if mix + tt >= 0 and mix + tt < len(cosa.matriz[0]):
				if cosa.matriz[miy][mix + tt]:
					return True
		return False
	def muro_R(self):
		miy = ynt(self.y/BLOQ)
		mix = ynt((JUGANCH + self.x + 0.5)/BLOQ)
		if mix < 0 or mix >= len(self.ancla.matriz[0]):
			return False, False
		for tt in range(int(JUGALT/BLOQ) - (self.y%BLOQ == 0)):
			if miy + tt >= 0 and miy + tt < len(self.ancla.matriz):
				if self.ancla.matriz[miy + tt][mix]:
					return True, True
		return False, self.ancla.matriz[miy + ynt(JUGALT/BLOQ) - 1][mix]
	def muro_L(self):
		self.x -= JUGANCH
		aux = self.muro_R()
		self.x += JUGANCH
		return aux
	def wall_R(self, cosa):
		miy = ynt((self.y - cosa.y + 0.3)/BLOQ)
		mix = ynt((JUGANCH + self.x - cosa.x + 0.3)/BLOQ)
		if mix < 0 or mix >= len(cosa.matriz[0]):
			return False, False
		for tt in range(int(JUGALT/BLOQ) - (self.y%BLOQ == 0)):
			if miy + tt >= 0 and miy + tt < len(cosa.matriz):
				if cosa.matriz[miy + tt][mix]:
					return True, True
		aux = miy + ynt(JUGALT/BLOQ) - 1
		if aux < 0 or aux >= len(cosa.matriz):
			return False, False
		return False, cosa.matriz[aux][mix]
	def wall_L(self, cosa):
		self.x -= JUGANCH
		aux = self.wall_R(cosa)
		self.x += JUGANCH
		return aux
	def hay_techo(self):
		return False#[...]
	def mover(self, grav, barcos):
		self.x += self.vx
		self.y += self.vy
		if self.ancla:
			self.vx *= ROZ_TIERRA
			self.vy *= ROZ_TIERRA
			if self.muro_L()[0]:
				self.x = ynt(self.x/BLOQ)*BLOQ + BLOQ
				self.vx = 0
			if self.muro_R()[0]:
				self.x = ynt(self.x/BLOQ)*BLOQ
				self.vx = 0
			if not self.hay_piso():
				self.reanclar(False)
		else:
			self.vy += grav
			self.vy *= ROZ_AIRE
			self.vx *= ROZ_AIRE
			for barco in barcos:
				if self.wall_R(barco)[0]:
					self.x = ynt(self.x/BLOQ)*BLOQ
					self.vx = 0
				if self.wall_L(barco)[0]:
					self.x = ynt(self.x/BLOQ)*BLOQ + BLOQ
					self.vx = 0
				if self.ground(barco):
					self.reanclar(barco)
					self.y = BLOQ*ynt(self.y/BLOQ)
					self.vy = 0
					break
	def reanclar(self, ancla2):
		if self.ancla != False:
			self.x += self.ancla.x
			self.y += self.ancla.y
		if ancla2 != False:
			self.x -= ancla2.x
			self.y -= ancla2.y
		self.ancla = ancla2
	def saltar(self):
		if self.ancla:
			self.reanclar(False)
			self.vy -= self.vsalto
	def controlar(self, tR, tU, tD, tL):
		self.vx += self.agil*(tR - tL)
		if tU:
			self.saltar()
	def dibujar(self, camara_x, camara_y):
		if self.ancla:
			self.imagen.poner(self.x + self.ancla.x - camara_x, self.y + self.ancla.y - camara_y)
		else:
			self.imagen.poner(self.x - camara_x, self.y - camara_y)

class Suelo:
	def __init__(self, matriz, fondo):
		self.x, self.y = 0, 0
		self.matriz = matriz
		self.fondo = Imagen(fondo)
	def dibujar(self, camara_x, camara_y):
		for ii in range(len(self.matriz)):
			if abs(self.y + BLOQ*ii - camara_y - SCREEN_HEIGHT/2) < SCREEN_HEIGHT/2 + BLOQ:
				for jj in range(len(self.matriz[0])):
					if abs(self.x + BLOQ*jj - camara_x - SCREEN_WIDTH/2) < SCREEN_WIDTH/2 + BLOQ:
						if self.matriz[ii][jj]:
							BLOQ_IMGS[self.matriz[ii][jj]].poner(self.x + BLOQ*jj - camara_x, self.y + BLOQ*ii - camara_y)

class Nave:
	def __init__(self, xxx, yyy, matriz, descripcion):
		self.matriz = matriz
		self.sombra = [[matriz[0][0]] + [matriz[0][jj] or matriz[0][jj + 1] for jj in range(len(matriz[0]) - 1)] + [matriz[0][len(matriz[0]) - 1]]]
		self.sombra += [[matriz[ii][0] or matriz[ii + 1][0]] + [matriz[ii][jj] or matriz[ii][jj + 1] or matriz[ii + 1][jj] or matriz[ii + 1][jj + 1] for jj in range(len(matriz[0]) - 1)] + [matriz[ii][len(matriz[0]) - 1] or matriz[ii + 1][len(matriz[0]) - 1]] for ii in range(len(matriz) - 1)]
		self.sombra += [[matriz[len(matriz) - 1][0]] + [matriz[len(matriz) - 1][jj] or matriz[len(matriz) - 1][jj + 1] for jj in range(len(matriz[0]) - 1)] + [matriz[len(matriz) - 1][len(matriz[0]) - 1]]]
		self.bando, self.accion = descripcion
		self.vx, self.vy, self.x, self.y = 0, 0, xxx, yyy
		self.trR, self.trU, self.trD, self.trL = 1, 1, 1, 1
		self.peso = 1
	def mover(self, grav):
		self.x += self.vx
		self.y += self.vy
		self.vx *= ROZ_AIRE
		self.vy *= ROZ_AIRE
	def controlar(self, tR, tU, tD, tL):
		self.vx += (tR*self.trR - tL*self.trL)/self.peso
		self.vy += (tD*self.trD - tU*self.trU)/self.peso
	def dibujar(self, camara_x, camara_y):
		for ii in range(len(self.matriz)):
			if abs(self.y + BLOQ*ii - camara_y - SCREEN_HEIGHT/2) < SCREEN_HEIGHT/2 + BLOQ:
				for jj in range(len(self.matriz[0])):
					if abs(self.x + BLOQ*jj - camara_x - SCREEN_WIDTH/2) < SCREEN_WIDTH/2 + BLOQ:
						if self.matriz[ii][jj]:
							BLOQ_IMGS[self.matriz[ii][jj]].poner(self.x + BLOQ*jj - camara_x, self.y + BLOQ*ii - camara_y)

class Boton:
	def __init__(self, xxx, yyy, texto, accion):
		self.texto = texto
		self.accion = accion
		self.x, self.y = xxx, yyy
	def dibujar(self, mousex, mousey):
		self.texto.poner(self.x, self.y)
	def usar(self):
		self.accion()

#"tlwgtypewriter"
def spam_imgs(lis):
	for text, xx, yy in lis:
		if xx == -1:
			xx = SCREEN_WIDTH/2 - text.rect[2]/2
		if yy == -1:
			yy = SCREEN_HEIGHT/2 - text.rect[3]/2
		text.poner(xx, yy)

def color_mapper(color):
	if color == NEGRO:
		return 6
	if color == BLANCO:
		return 0
	return 0

def parseimg(file_name):
	auxsurf = pygame.image.load(PATH + 'img/' + file_name)
	return [map(color_mapper, [auxsurf.get_at((jj, ii)) for jj in range(auxsurf.get_rect()[2])]) for ii in range(auxsurf.get_rect()[3])]

def terminate():
	pygame.quit()
	sys.exit()

def ynt(num):
	if num > 0:
		return int(num)
	return int(num) - 1

if 2 + 2 == 4:
	main()