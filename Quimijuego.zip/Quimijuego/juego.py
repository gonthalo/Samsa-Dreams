import os, inspect, sys, math, random, pygame, pygame.mixer
from time import time
from random import random
from pygame.locals import *

camino = inspect.getfile(inspect.currentframe())[:-8]
screen_size = screen_width, screen_height = 1200, 700
screen = pygame.display.set_mode(screen_size)
clock = pygame.time.Clock()
pygame.display.set_caption('Juego Chachidiver')
key_controls = [pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT]
key_atajos = [pygame.K_ESCAPE, pygame.K_i, pygame.K_e, pygame.K_d]
key_numeros = [pygame.K_0, pygame.K_1, pygame.K_2, pygame.K_3, pygame.K_4, pygame.K_5, pygame.K_6, pygame.K_7, pygame.K_8, pygame.K_9]
exit_game_forever = False
gravedad = 0.5
barcos = []
suelo = []
camara_x = 0
camara_y = 0

class Imagen:
	def __init__(self, file_name):
		self.area = pygame.image.load(camino + 'img/' + file_name)
		self.rect = self.area.get_rect()
	def poner(self, i_x, i_y, phi=0):
		screen.blit(pygame.transform.rotate(self.area, phi), self.rect.move(i_x, i_y))

class Papeeel:
	def __init__(self, reactivos, productos, indice):
		self.reactivos = reactivos
		self.productos = productos
		self.ind = indice
	def mostrar(self):
		print 'REACTIVOS'
		for elem, cant in self.reactivos:
			print cant, 'x', elem
		print ''
		print 'PRODUCTOS'
		for elem, cant in self.productos:
			print cant, 'x', elem
		print ''
		print 'Pagina ' + str(self.ind) + ' del diario del gran JMHH'

class Nave:
	def __init__(self, xxx, yyy, matriz, descripcion):
		self.matriz = matriz
		self.sombra = [[matriz[0][0]] + [matriz[0][jj] or matriz[0][jj + 1] for jj in range(len(matriz[0]) - 1)] + [matriz[0][len(matriz[0]) - 1]]]
		self.sombra += [[matriz[ii][0] or matriz[ii + 1][0]] + [matriz[ii][jj] or matriz[ii][jj + 1] or matriz[ii + 1][jj] or matriz[ii + 1][jj + 1] for jj in range(len(matriz[0]) - 1)] + [matriz[ii][len(matriz[0]) - 1] or matriz[ii + 1][len(matriz[0]) - 1]] for ii in range(len(matriz) - 1)]
		self.sombra += [[matriz[len(matriz) - 1][0]] + [matriz[len(matriz) - 1][jj] or matriz[len(matriz) - 1][jj + 1] for jj in range(len(matriz[0]) - 1)] + [matriz[len(matriz) - 1][len(matriz[0]) - 1]]]
		self.bando, self.accion = descripcion
		self.vx, self.vy, self.x, self.y = 0, 0, xxx, yyy
	def dibujar(self):
		for ii in range(len(self.matriz)):
			for jj in range(len(self.matriz[0])):
				if self.matriz[ii][jj]:
					bloq_imgs[self.matriz[ii][jj]].poner(self.x + 15*jj - camara_x, self.y + 15*ii - camara_y)
	def mover(self):
		self.x += self.vx
		self.y += self.vy
		self.vx *= 0.9
		self.vy += gravedad
		self.vy *= 0.9
	def controlar(self, teclas):
		if sum(teclas)!=0:
			self.vx += teclas[3] - teclas[2]
			self.vy += teclas[1] - teclas[0]
	@staticmethod
	def choque(nave1, nave2):
		difx = int((nave2.x - nave1.x)/15)
		dify = int((nave2.y - nave1.y)/15)
		if difx >= len(nave1.matriz[0]) or dify >= len(nave1.matriz):
			return False
		x_1 = max(0, difx)
		x_2 = min(len(nave1.matriz[0]), len(nave2.matriz[0]) + difx)
		y_1 = max(0, dify)
		y_2 = min(len(nave1.matriz), len(nave2.matriz) + dify)
		for ii in range(x_1, x_2):
			if sum([nave1.sombra[ii][jj] and nave2.matriz[ii + difx][jj] for jj in range(y_1, y_2)]):
				return True
		return False

class Persona:
	def __init__(self, xxx, yyy, nombre, imagen):
		self.x, self.y = xxx, yyy
		self.nombre = nombre
		self.vx, self.vy = 0, 0
		self.ancla = False
		self.imagen = Imagen(imagen)
		self.altura = 7
	def mover(self):
		self.x += self.vx
		self.y += self.vy
		if not self.ancla:
			self.vy += 2*gravedad
			#if suelo[int(self.x/15)][int(self.y/15)]:
			#	self.ancla = 'Suelo'
			for barco in barcos:
				if self.x > barco.x and self.x < barco.x + 15*len(barco.matriz) and self.y + 15*self.altura + 15 > barco.y and self.y + 15*self.altura + 15 < barco.y + 15*len(barco.matriz[0]):
					print 'dentro', self.x, barco.x, self.y, barco.y
					if barco.matriz[int((self.x - barco.x)/15)][int((self.y - barco.y)/15) + self.altura + 1]:
						self.reanclar(barco)
						self.vy = 0.
						self.y = 15*int(self.y/15 - 1)
		#print 'P', int(self.x), int(self.y) + self.altura*15
		self.vy *= 0.95
		self.vx *= 0.95
		if self.ancla != False:
			self.vx*=0.8
		camara_y = self.y + int(15*self.altura/2) - screen_height/2
		camara_x = self.x - screen_width/2
		if self.ancla:
			camara_y += self.ancla.y
			camara_x += self.ancla.x
		#print camara_x, camara_y
	def reanclar(self, ancla2):
		if self.ancla != False:
			self.x += self.ancla.x
			self.y += self.ancla.y
		if ancla2 != False:
			self.x -= ancla2.x
			self.y -= ancla2.y
		self.ancla = ancla2
	def saltar(self):
		if self.ancla:
			self.reanclar(False)
			self.vy -= 10
	def controlar(self, teclas):
		self.vx += 2*teclas[3] - 2*teclas[2]
		if teclas[0]:
			self.saltar()
	def dibujar(self):
		if self.ancla in [False, 'Suelo']:
			self.imagen.poner(self.x - camara_x, self.y - camara_y)
		else:
			self.imagen.poner(self.x + self.ancla.x - camara_x, self.y + self.ancla.y - camara_y)


def poner_texto(cadena, alto):
	screen.fill((0, 0, 0))
	pygame.font.init()
	fuente = pygame.font.SysFont("tlwgtypewriter", 50)
	dy = alto*len(cadena)/2
	for ind in range(len(cadena)):
		texto = fuente.render(cadena[ind], True, (255, 255, 255), (0, 0, 0))
		dx = texto.get_rect().width/2
		screen.blit(texto, texto.get_rect().move(screen_width/2 - dx, screen_height/2 + alto*ind - dy))
	pygame.display.flip()

def esperar(tiempo):
	for ii in range(tiempo):
		for evento in pygame.event.get():
			if evento.type == pygame.QUIT:
				exit_game_forever = True
		clock.tick(200)

poner_texto(["Un jueguecito", "de la mano de", "ANGOSOFT"], 50)
esperar(100)
print camino
archivo = open(camino + 'cosas/bloques', 'r')
bloques = [linea[:-1] for linea in archivo.readlines()]
print bloques
bloq_imgs = [Imagen('bloque' + str(ii) + '.png') for ii in range(len(bloques))]
archivo.close()

papel1 = Papeeel([('arena', 20), ('agua', 12)], [('barro', 20)], 1)
papel1.mostrar()
nave1 = Nave(100, 100, [[1, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 0, 1], [1, 0, 0, 0, 0, 0, 1], [1, 1, 1, 1, 1, 1, 1]], ('malo', 'pasivo'))
nave1.dibujar()
pygame.display.flip()
nave1.vx = 2
nave1.vy = 1
pilotando = False
monigote = Persona(20, -45, 'Monigote', 'monigote.png')
monigote.ancla = nave1
key_n_rec = False
key_p_rec = False
menu = False
pausa = False
barcos = [nave1]
while True:
	eventos = 0
	pressed = pygame.key.get_pressed()
	if not pausa:
		screen.fill((10, 250, 120))
		nave1.mover()
		nave1.dibujar()
		monigote.mover()
		monigote.dibujar()
		pygame.display.flip()
		teclas = [pressed[ii]!=0 for ii in key_controls]
		if pressed[pygame.K_n] and not key_n_rec:
			pilotando = not pilotando
			key_n_rec = True
		if key_n_rec and not pressed[pygame.K_n]:
			key_n_rec = False
		if pilotando:
			nave1.controlar(teclas)
		else:
			monigote.controlar(teclas)
		esperar(10)
	if pressed[pygame.K_p] and not key_p_rec:
		pausa = not pausa
		key_p_rec = True
	if key_p_rec and not pressed[pygame.K_p]:
		key_p_rec = False
	if pressed[pygame.K_F4]:
		pygame.quit()
		sys.exit()
		break
	if pressed[pygame.K_ESCAPE]:
		menu = 'ajustes'
	print key_p_rec

